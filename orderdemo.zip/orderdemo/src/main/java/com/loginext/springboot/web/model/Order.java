package com.loginext.springboot.web.model;

/**
 * @author Sairam
 *
 */
public class Order {

}
