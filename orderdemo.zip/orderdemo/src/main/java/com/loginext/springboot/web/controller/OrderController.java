package com.loginext.springboot.web.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.loginext.springboot.web.model.Driver;
import com.loginext.springboot.web.service.OrderService;

/**
 * @author Sairam
 *
 */

@Controller
@SessionAttributes("name")
public class OrderController {

	@Autowired
	OrderService service;
	
	@RequestMapping(value="/login", method = RequestMethod.GET)
	public String showLoginPage(ModelMap model){
        return "login";
    }
	
	@RequestMapping(value="/login", method = RequestMethod.POST)
    public String showWelcomePage(ModelMap model, @RequestParam String name, @RequestParam String password){
        boolean isValidUser = service.validateUser(name, password);
        if (!isValidUser) {
            model.put("errorMessage", "Invalid Credentials");
            return "login";
        }
        model.put("name", name);
        model.put("password", password);
        return "welcome";
    }
	
	@RequestMapping(value="/getBookingDetails", method = RequestMethod.POST)
    public String getCustomerDetails(ModelMap model, @RequestParam String lattitude, @RequestParam String longitude){
        List<Driver> bookDetails = service.getBookingDetails(lattitude, longitude);
        if (bookDetails != null && bookDetails.size() > 1) {
        	
        	model.addAttribute("lists", bookDetails);
        	return "book-details";
        } else {
        	model.put("errorMessage", "Booking now available.");
        	model.addAllAttributes(bookDetails);
        	return "book-details";
        }
    }
}
