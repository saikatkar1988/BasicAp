package com.loginext.springboot.web.model;

/**
 * @author Sairam
 *
 */
public class Customer {

	int custid;
	String custname;
	String custlatitude;
	String custlongitude;
	String status;

	public int getCustid() {
		return custid;
	}

	public void setCustid(int custid) {
		this.custid = custid;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getCustlatitude() {
		return custlatitude;
	}

	public void setCustlatitude(String custlatitude) {
		this.custlatitude = custlatitude;
	}

	public String getCustlongitude() {
		return custlongitude;
	}

	public void setCustlongitude(String custlongitude) {
		this.custlongitude = custlongitude;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}