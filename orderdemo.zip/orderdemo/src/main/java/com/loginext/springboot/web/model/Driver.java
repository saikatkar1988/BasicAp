package com.loginext.springboot.web.model;

public class Driver {

	int id;
	String name;
	String curlatitude;
	String curlongitude;
	String status;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCurlatitude() {
		return curlatitude;
	}

	public void setCurlatitude(String curlatitude) {
		this.curlatitude = curlatitude;
	}

	public String getCurlongitude() {
		return curlongitude;
	}

	public void setCurlongitude(String curlongitude) {
		this.curlongitude = curlongitude;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
