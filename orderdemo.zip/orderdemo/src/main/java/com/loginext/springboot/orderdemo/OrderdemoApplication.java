package com.loginext.springboot.orderdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan("com.loginext.springboot.web")
public class OrderdemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderdemoApplication.class, args);
	}

}
