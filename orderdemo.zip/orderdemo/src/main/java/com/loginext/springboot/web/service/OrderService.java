package com.loginext.springboot.web.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.loginext.springboot.web.model.Driver;

/**
 * @author Sairam
 *
 */

@Service
public class OrderService {

	public boolean validateUser(String userid, String password) {
		return userid.equalsIgnoreCase("loginext") && password.equalsIgnoreCase("loginext");
	}

	public List<Driver> getBookingDetails(String lattitude, String longitude) {

		List<Driver> bdetailList = new ArrayList<Driver>();
		// get the booking details from DB
		// as of now making it hardcoad

		/*Driver bdetails1 = new Driver();
		bdetails1.setId(1);
		bdetails1.setName("Aditya");
		bdetails1.setCurlatitude("1.23123213123");
		bdetails1.setCurlongitude("1.23123232346");
		bdetails1.setStatus("Busy");
		
		Driver bdetails2 = new Driver();
		bdetails2.setId(2);
		bdetails2.setName("Ram");
		bdetails2.setCurlatitude("1.23123213123");
		bdetails2.setCurlongitude("1.23123232346");
		bdetails2.setStatus("Busy");
		
		Driver bdetails3 = new Driver();
		bdetails3.setId(3);
		bdetails3.setName("Sairam");
		bdetails3.setCurlatitude("1.23123213123");
		bdetails3.setCurlongitude("1.23123232346");
		bdetails3.setStatus("Available");
		
		bdetailList.add(bdetails1);
		bdetailList.add(bdetails2);
		bdetailList.add(bdetails3);*/
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/order", "root", "root");
			// here order is database name, root is username and password
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("select * from driver");
			Driver driver = null;
			while (rs.next()) {
				System.out.println(rs.getInt(1) + "  " + rs.getString(2) + "  " + rs.getString(3));
				driver = new Driver();
				driver.setId(rs.getInt(1));
				driver.setName(rs.getString(2));
				driver.setCurlatitude(rs.getString(3));
				driver.setCurlongitude(rs.getString(4));
				bdetailList.add(driver);
			}
			con.close();
		} catch (Exception e) {
			System.out.println(e);
		}

		if (bdetailList != null && bdetailList.size() > 0) {

			return bdetailList;
		} else {

			return null;
		}
	}
}
